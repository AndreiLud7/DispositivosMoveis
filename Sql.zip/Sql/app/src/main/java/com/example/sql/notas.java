package com.example.sql;

public class notas {

    public notas(int id, String txt) {
        this.id = id;
        this.txt = txt;
    }

    int id;
    String txt;

}
