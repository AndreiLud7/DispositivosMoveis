package com.example.listar;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {

    String [] nomes = new String[]{"Jorge", "Maria", "Jose", "lUisa"};
    ListView lv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lv = findViewById(R.id.listview);

        //configurando um adaptador para listagem de dados

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(
                getApplicationContext(),
                android.R.layout.simple_list_item_1,
                android.R.id.text1,
                nomes

        );

        lv.setAdapter(adapter);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Log.d("clickItem", Integer.toString(i));
                Log.d("clickItem", nomes([i]);

                Bundle  b = new Bundle();
                b.putString("Nomes", nomes[i]);
                Intent i = new Intent(getApplicationContext(), segundaActivity.class);
                i.putExtra(b);
                startActivity(i);
            }
        });

    }
}