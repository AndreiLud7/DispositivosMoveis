package com.example.tts;

import android.content.Context;
import android.speech.tts.TextToSpeech;

public class TTS implements TextToSpeech.OnInitListener {

    TextToSpeech textToSpeech;

    public TTS(Context c){
        textToSpeech = new TextToSpeech(c, this);
    }
    @Override
    public void onInit(int i) {

    }
}
